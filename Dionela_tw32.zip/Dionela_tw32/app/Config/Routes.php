<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultController('Index');

$routes->get('/', 'Index::index');
$routes->get('index', 'Index::index');
$routes->get('index/index', 'Index::index');
$routes->get('home', 'Index::index');

$routes->get('index/showdata', 'Index::showData');
$routes->get('index/showdata/(:alpha)/(:num)', 'Index::showData/$1/$2');
$routes->get('index/about', 'Index::about');

// User Management Routes
$routes->get('users', 'Users::index');
$routes->get('users/add', 'Users::add');
$routes->post('users/add', 'Users::add');
$routes->get('users/activate/(:any)', 'Users::activate/$1');
$routes->get('users/view/(:num)', 'Users::view/$1');
$routes->get('users/edit/(:num)', 'Users::edit/$1');
$routes->post('users/edit/(:num)', 'Users::edit/$1');
$routes->get('users/delete/(:num)', 'Users::delete/$1');

// Login and Logout Routes
$routes->get('login', 'Index::login');
$routes->get('index/login', 'Index::login');
$routes->post('index/login', 'Index::login');
$routes->post('index/loginSubmit', 'Index::loginSubmit'); // Add this line
$routes->get('logout', 'Index::logout');


$routes->get('register', 'RegisterController::index');

// Equipment Management Routes
$routes->get('equipment', 'EquipmentController::index'); // List all equipment
$routes->get('equipment/create', 'EquipmentController::create'); // Display the creation form
$routes->post('equipment/create', 'EquipmentController::store'); // Handle equipment creation
$routes->get('equipment/edit/(:num)', 'EquipmentController::edit/$1'); // Display edit form
$routes->post('equipment/edit/(:num)', 'EquipmentController::update/$1'); // Handle editing
$routes->get('equipment/delete/(:num)', 'EquipmentController::delete/$1'); // Delete equipment

// Borrowing Module Routes
$routes->get('borrowings', 'BorrowingController::index');
$routes->get('borrowings/view/(:num)', 'BorrowingController::view/$1');
$routes->get('borrowings/add', 'BorrowingController::add');
$routes->post('borrowings/create', 'BorrowingController::create');
$routes->get('borrowings/return/(:num)', 'BorrowingController::return/$1');



// Reservation Module Routes
$routes->get('reservation', 'ReservationController::index'); // Display all reservations
$routes->get('reservation/create', 'ReservationController::create'); // Display create reservation form
$routes->post('reservation/create', 'ReservationController::store'); // Handle new reservation
$routes->get('reservation/edit/(:num)', 'ReservationController::edit/$1'); // Display edit reservation form
$routes->post('reservation/edit/(:num)', 'ReservationController::update/$1'); // Handle reservation update
$routes->get('reservation/cancel/(:num)', 'ReservationController::cancel/$1'); // Cancel reservation
$routes->get('reservation/history', 'ReservationController::history'); // View reservation history

// Reports Module Routes
$routes->get('reports/active-equipment', 'ReportsController::activeEquipmentReport'); // Generate active equipment list report
$routes->get('reports/unusable-equipment', 'ReportsController::unusableEquipmentReport'); // Generate unusable equipment report
$routes->get('reports/user-borrowing-history/(:num)', 'ReportsController::userBorrowingHistory/$1'); // Generate user borrowing history report for a specific user

// New routes for exporting reports (optional, if required)
$routes->get('reports/active-equipment/export', 'ReportsController::exportActiveEquipment'); // Export active equipment report
$routes->get('reports/unusable-equipment/export', 'ReportsController::exportUnusableEquipment'); // Export unusable equipment report
$routes->get('reports/user-borrowing-history/(:num)/export', 'ReportsController::exportUserBorrowingHistory/$1'); // Export user borrowing history report for a specific user

// Add additional routes for better management or admin functionality if needed
$routes->get('admin/dashboard', 'AdminController::dashboard'); // Admin Dashboard (optional)

// Error Handling Routes (optional)
$routes->get('error/404', 'ErrorController::notFound'); // 404 error handling route
