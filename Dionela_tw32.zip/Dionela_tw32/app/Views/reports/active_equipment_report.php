<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Equipment Report</title>
</head>
<body>
    <h1>Active Equipment List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Equipment Name</th>
                <th>Model</th>
                <th>Status</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($equipment as $item): ?>
                <tr>
                    <td><?= esc($item['name']) ?></td>
                    <td><?= esc($item['model']) ?></td>
                    <td><?= esc($item['status']) ?></td>
                    <td><?= esc($item['location']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
