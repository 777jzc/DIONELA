<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Borrowing History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
        }
        h1 {
            color: #5d5d5d;
        }
        .btn {
            margin-top: 20px;
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>User Borrowing History</h1>

        <?php if (empty($borrowingHistory)): ?>
            <p>No borrowing history found for this user.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Equipment Name</th>
                        <th>Borrow Date</th>
                        <th>Return Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($borrowingHistory as $borrow): ?>
                        <tr>
                            <td><?= esc($borrow['equipment_name']) ?></td>
                            <td><?= esc($borrow['borrow_date']) ?></td>
                            <td><?= esc($borrow['return_date']) ?></td>
                            <td><?= esc($borrow['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <a href="<?= base_url('users'); ?>" class="btn">Back to Users</a>
    </div>

</body>
</html>
