<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Equipment</title>
</head>
<body>
    <h1>Return Equipment</h1>

    <p>Are you sure you want to return the equipment <strong><?= $equipment['name']; ?></strong>?</p>

    <form action="<?= base_url('return/' . $borrow_id); ?>" method="post">
        <button type="submit">Confirm Return</button>
    </form>
</body>
</html>
