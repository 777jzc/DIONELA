<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to The IT Services Office</title>
    <link rel="stylesheet" href="<?= base_url('public/css/styles.css'); ?>">
</head>
<body>
    <div class="container position-relative" style="padding-top: 2%; padding-left: 5%; padding-right: 5%;">
		<h1 class="text-center text-white font-weight-bold" style="padding: 2%;">Welcome!</h1>

        <div class="box-container">
            <!-- Box 1: About -->
            <div class="box">
                <img src="<?= base_url('public/images/chillguy.png'); ?>" alt="Welcome Image">
                <div class="card-body">
                    <h5>Welcome User!</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">Learn more about our IT services and offerings.</p>
                    <a href="<?= base_url('index/about'); ?>" class="btn btn-success">About</a>
                </div>
            </div>

            <!-- Box 2: Users -->
            <div class="box">
				<img src="<?= base_url('public/images/chillguy.png'); ?>" alt="User Management">
                <div class="card-body">
                    <h5>Manage Users</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">Track every member and manage their roles.</p>
                    <a href="<?= base_url('users'); ?>" class="btn btn-success">Users</a>
                </div>
            </div>

            <!-- Box 3: Equipment Management -->
            <div class="box">
				<img src="<?= base_url('public/images/chillguy.png'); ?>" alt="Equipment Management">
                <div class="card-body">
                    <h5>Manage Equipment</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">Add, edit, or view the IT equipment inventory.</p>
                    <a href="<?= base_url('equipment'); ?>" class="btn btn-success">Equipment</a>
                </div>
            </div>

            <!-- Box 4: Borrowing Module -->
            <div class="box">
				<img src="<?= base_url('public/images/chillguy.png'); ?>" alt="Borrowing Management">
                <div class="card-body">
                    <h5>Borrow Equipment</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">Borrow and track equipment and gadgets.</p>
                    <a href="<?= base_url('borrowing/borrow'); ?>" class="btn btn-success">Borrow Equipment</a>
                </div>
            </div>

            <!-- Box 5: Reservation Module -->
            <div class="box">
				<img src="<?= base_url('public/images/chillguy.png'); ?>" alt="Reservation Management">
                <div class="card-body">
                    <h5>Make a Reservation</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">Reserve equipment ahead of time for upcoming events.</p>
                    <a href="<?= base_url('reservation'); ?>" class="btn btn-success">Reservations</a>
                </div>
            </div>

            <!-- Box 6: Report Module -->
            <div class="box">
				<img src="<?= base_url('public/images/chillguy.png'); ?>" alt="Report Management">
                <div class="card-body">
                    <h5>Generate Reports</h5>
                    <p style="padding-left: 2%; padding-right: 2%;">View reports on equipment and users.</p>
                    <a href="<?= base_url('reports'); ?>" class="btn btn-success">Reports</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
