<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Borrowing Records</title>
    <style>
        body {
            background-color: #f4f4f4;
            background: linear-gradient(109.6deg, rgb(157, 75, 199) 11.2%, rgb(119, 81, 204) 83.1%);
            padding: 20px;
        }
        h1 {
            font-weight: 600;
            color: #fdfdfe;
            text-shadow: 0px 0px 5px #b393d3, 0px 0px 10px #b393d3;
            -webkit-text-stroke-width: 0.5px;
            -webkit-text-stroke-color: black;
            margin-bottom: 20px;
        }
        .btn {
            background-color: #03e9f4;
            color: white;
        }
        .btn:hover {
            background-color: #1198e2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Borrowing Records</h1>

        <!-- Borrowing Records Table -->
        <table class="table table-striped">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">User Name</th>
                    <th scope="col">Equipment Name</th>
                    <th scope="col">Borrow Date</th>
                    <th scope="col">Return Date</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($borrowing_records) && is_array($borrowing_records)): ?>
                    <?php foreach ($borrowing_records as $record): ?>
                        <tr>
                            <th scope="row"><?= esc($record['borrow_id']) ?></th>
                            <td><?= esc($record['name']) ?></td>
                            <td><?= esc($record['equipment_name']) ?></td>
                            <td><?= esc($record['borrow_date']) ?></td>
                            <td><?= esc($record['return_date']) ?></td>
                            <td>
                                <span class="badge badge-<?= $record['status'] == 'returned' ? 'success' : 'warning' ?>">
                                    <?= esc($record['status']) ?>
                                </span>
                            </td>
                            <td>
                                <!-- Action buttons (Return, View, etc.) -->
                                <?php if ($record['status'] != 'returned'): ?>
                                    <a href="<?= base_url('borrowing/return/' . $record['borrow_id']) ?>" class="btn btn-primary btn-sm">Return</a>
                                <?php endif; ?>
                                <a href="<?= base_url('borrowing/view/' . $record['borrow_id']) ?>" class="btn btn-info btn-sm">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Add New Borrowing Record -->
        <a href="<?= base_url('borrowing/add') ?>" class="btn btn-success btn-lg">Add New Borrowing</a>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
