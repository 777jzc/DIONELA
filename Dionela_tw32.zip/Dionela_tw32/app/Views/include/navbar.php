<nav class="navbar navbar-expand-lg navbar-light" style="background-color: rgba(255, 255, 255, 0.5);">
    <div class="container-fluid" style="padding-left: 2%;">
        <a class="navbar-brand" href="<?= base_url(); ?>" style="border: 1px solid black;">IT Services Office</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (uri_string() == 'index') ? 'active' : '' ?>" aria-current="page" href="<?= base_url('index'); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (uri_string() == 'index/about') ? 'active' : '' ?>" href="<?= base_url('index/about'); ?>">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (uri_string() == 'equipments') ? 'active' : '' ?>" href="<?= base_url('equipments'); ?>">Equipments</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (uri_string() == 'users') ? 'active' : '' ?>" href="<?= base_url('users'); ?>">Users</a>
                </li>
            </ul>

            <!-- Right-side links (Search & Profile) -->
            <form class="d-flex me-3" role="search" style="padding-right: 16%;">
                <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search" style="background-color: rgba(255, 255, 255, 0.25);">
                <button style="background-color: rgba(255, 255, 255, 0.25); color: black; border-color: rgba(0, 0, 0, 0.5);" type="submit">Search</button>
            </form>

            <!-- User Authentication Links -->
            <ul class="navbar-nav" style="padding-right: 2%;">
                <?php if (session()->get('isLoggedIn')): ?>
                    <li class="nav-item" style="color: black;">
                        <a class="nav-link <?= (uri_string() == 'profile') ? 'active' : '' ?>" href="<?= base_url('profile'); ?>">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('logout'); ?>">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link <?= (uri_string() == 'login') ? 'active' : '' ?>" href="<?= base_url('login'); ?>" style="border: 1px solid black;">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>