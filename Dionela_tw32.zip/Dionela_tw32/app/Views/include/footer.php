<!--
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }
        .content {
            flex: 1;
        }
        footer {
            width: 100%;
            background-color: rgba(255, 255, 255, 0.5); /* Same background as navbar */
            color: #000000; /* Change text color to black */
            left: 0;
            right: 0;
            padding: 10px 0; /* Add padding for spacing */
            position: relative; /* Ensure footer is at the bottom of the content */
            bottom: 0;
        }
    </style>
</head>
<body>
    <footer class="container-fluid text-dark">
        <div class="row">
            <div class="col-md-4 text-center py-2">
                <h5>Contact Us</h5>
                <p class="mb-1">Email: theglowsery@example.com</p>
                <p class="mb-1">Phone: +63 099 444 5555</p>
            </div>
            <div class="col-md-4 text-center py-2">
                <h5>Follow Us</h5>
                <a href="#" class="text-dark me-2">Facebook</a>
                <a href="#" class="text-dark">Twitter</a>
            </div>
        </div>
        <div class="text-center py-2">
            <p class="mb-0">&copy; <?= date('Y'); ?> The Glowsery. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>
	-->