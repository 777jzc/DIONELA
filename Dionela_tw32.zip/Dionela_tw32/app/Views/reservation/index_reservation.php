<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<h2>Your Reservations</h2>
<table class="table">
    <thead>
        <tr>
            <th>Equipment</th>
            <th>Reservation Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($reservations as $reservation): ?>
            <tr>
                <td><?= $reservation['equipment_id'] ?></td>
                <td><?= $reservation['reservation_date'] ?></td>
                <td><?= $reservation['status'] ?></td>
                <td>
                    <?php if ($reservation['status'] == 'reserved'): ?>
                        <a href="<?= base_url('reservation/cancel/' . $reservation['id']) ?>" class="btn btn-danger">Cancel</a>
                        <a href="<?= base_url('reservation/reschedule/' . $reservation['id']) ?>" class="btn btn-warning">Reschedule</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a href="<?= base_url('reservation/create') ?>" class="btn btn-success">Reserve Equipment</a>
