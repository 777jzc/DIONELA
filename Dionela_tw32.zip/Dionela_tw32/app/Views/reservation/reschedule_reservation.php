<h2>Reschedule Reservation</h2>
<form method="POST">
    <div class="form-group">
        <label for="new_date">New Reservation Date</label>
        <input type="date" name="new_date" id="new_date" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Reschedule</button>
</form>
