<h2>Create Reservation</h2>
<form method="POST">
    <div class="form-group">
        <label for="equipment_id">Equipment</label>
        <select name="equipment_id" id="equipment_id" class="form-control" required>
            <!-- Populate available equipment here -->
        </select>
    </div>
    <div class="form-group">
        <label for="reservation_date">Reservation Date</label>
        <input type="date" name="reservation_date" id="reservation_date" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Reserve</button>
</form>
