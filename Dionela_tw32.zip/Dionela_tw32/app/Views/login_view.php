<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login</title>
	<link rel="stylesheet" href="<?= base_url('public/css/styles.css') ?>">
</head>
<body>
	<div style="padding-top: 10%" class="d-flex align-items-center justify-content-center">
		<div class="w-25 m-0 p-0">
			<!-- Display error message if exists -->
			<?php if (session()->has('error')): ?>
				<div class="alert alert-danger">
					<p><?= session()->getFlashdata('error') ?></p>
				</div>
			<?php endif; ?>

			<!-- Display success message if exists -->
			<?php if (session()->has('success')): ?>
				<div class="alert alert-success">
					<p><?= session()->getFlashdata('success') ?></p>
				</div>
			<?php endif; ?>

			<form action="<?= base_url('index/loginSubmit'); ?>" method="post">
				<!-- CSRF Protection Field -->
				<?= csrf_field() ?>

				<!-- Username Field -->
				<div class="form-group mb-3">
					<label for="username" class="form-label" style="color: white;">Username</label>
					<input type="text" name="email" id="username" class="form-control" value="<?= old('email') ?>" required>
					<small class="text-danger"><?= session()->getFlashdata('email_error') ?></small>
				</div>

				<!-- Password Field -->
				<div class="form-group mb-3">
					<label for="password" class="form-label" style="color: white;">Password</label>
					<input type="password" name="password" id="password" class="form-control" required>
					<small class="text-danger"><?= session()->getFlashdata('password_error') ?></small>
				</div>

				<!-- Submit Button -->
				<div class="form-group mb-3">
					<button type="submit" class="btn btn-lg w-100" style="color: white; border: 2px solid white; font-weight: bold; background: none;"
						onmouseover="this.style.borderColor='#ffffff'; this.style.boxShadow='0 0 5px #ffffff, 0 0 25px #ffffff, 0 0 50px #ffffff, 0 0 200px #ffffff'; this.style.backgroundColor='white'; this.style.color='black';"
						onmouseout="this.style.borderColor='white'; this.style.boxShadow='none'; this.style.backgroundColor=''; this.style.color='white';">
						Log In
					</button>
				</div>
			</form>
		</div>
	</div>
</body>
</html>
