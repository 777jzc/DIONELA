<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About</title>
	<link rel="stylesheet" href="<?= base_url('public/css/styles.css'); ?>">
</head>
<body>
	<div style="padding-top: 2%;">
		<h2 style="color: white;" class="d-flex align-items-center justify-content-center">About Us</h2>
		<p style="color: white;" class="d-flex align-items-center justify-content-center">
		<strong>Meet our developers!</strong>
		</p>
	</div>

	<div style="padding-left: 30%; padding-right: 30%; color: white;">
		<div style="padding: 1%; border: 1px solid white; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
			<div>
				<h4>Dela Rosa, Jary Zaldy C.</h4>
				<p>Role: Developer</p>
			</div>
			<img src="<?= base_url('public/images/delarosa.png'); ?>" alt="delarosa" style="width: 100px; height: 100px;">
		</div>
		<div style="padding: 1%; border: 1px solid white; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
			<div>
				<h4>Peralta, Roozemond Vincent S.</h4>
				<p>Role: Developer</p>
			</div>
			<img src="<?= base_url('public/images/peralta.png'); ?>" alt="peralta" style="width: 100px; height: 100px;">
		</div>
		<div style="padding: 1%; border: 1px solid white; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
			<div>
				<h4>Rapirap, Jose Agustin A.</h4>
				<p>Role: Developer</p>
			</div>
			<img src="<?= base_url('public/images/rapirap.png'); ?>" alt="rapirap" style="width: 100px; height: 100px;">
		</div>
		<div style="padding: 1%; border: 1px solid white; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
			<div>
				<h4>Umali, Rhadler Klein Cedric Y.</h4>
				<p>Role: Developer</p>
			</div>
			<img src="<?= base_url('public/images/umali.png'); ?>" alt="umali" style="width: 100px; height: 100px;">
		</div>
	</div></div>

	<div style="position: absolute; bottom: 10px; left: 10px; padding: 2%;">
		<a href="<?= base_url(); ?>">Back to Home</a>
	</div>
</body>
</html>