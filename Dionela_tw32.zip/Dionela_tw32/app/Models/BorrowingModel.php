<?php

namespace App\Models;

use CodeIgniter\Model;

class BorrowingModel extends Model
{
    public function history($userId)
    {
        $borrowingModel = new BorrowingModel();

        // Get borrowing history for the user
        $borrowingHistory = $borrowingModel->getBorrowingWithEquipment($userId);

        // Pass the data to the view
        return view('reports/user_borrowing_history', ['borrowingHistory' => $borrowingHistory]);
    }
}
