<?php

namespace App\Models;

use CodeIgniter\Model;

class EquipmentModel extends Model
{
    protected $table = 'equipments';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'status', 'accessories'];

    public function updateEquipmentStatus($equipment_id, $status)
    {
        return $this->update($equipment_id, ['status' => $status]);
    }

    public function getEquipmentDetails($equipment_id)
    {
        return $this->find($equipment_id);
    }
}
