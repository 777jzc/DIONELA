<?php

namespace App\Models;

use CodeIgniter\Model;

class ReservationModel extends Model
{
    protected $table      = 'reservations';
    protected $primaryKey = 'id';
    protected $allowedFields = ['associate_id', 'equipment_id', 'reservation_date', 'status'];
    protected $useTimestamps = true;
    protected $returnType = 'array';

    public function getReservationsByAssociate($associate_id)
    {
        return $this->where('associate_id', $associate_id)->findAll();
    }

    public function getReservation($reservation_id)
    {
        return $this->find($reservation_id);
    }

    public function cancelReservation($reservation_id)
    {
        return $this->update($reservation_id, ['status' => 'cancelled']);
    }

    public function rescheduleReservation($reservation_id, $new_date)
    {
        return $this->update($reservation_id, ['reservation_date' => $new_date]);
    }

    public function createReservation($associate_id, $equipment_id, $reservation_date)
    {
        return $this->save([
            'associate_id' => $associate_id,
            'equipment_id' => $equipment_id,
            'reservation_date' => $reservation_date,
            'status' => 'reserved'
        ]);
    }
}
