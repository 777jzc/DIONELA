<?php

namespace App\Controllers;

use App\Models\BorrowingModel;
use App\Models\EquipmentModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class ReturnController extends Controller
{
    public function index()
    {
        // Logic to list borrowed items (for admin or user).
    }

    // Mark an equipment as returned and send email notification
    public function returnItem($borrow_id)
    {
        $borrowModel = new BorrowingModel();
        $equipmentModel = new EquipmentModel();
        $userModel = new UserModel();

        // Get the borrowing record details
        $borrowing = $borrowModel->getBorrowingDetails($borrow_id);
        if ($borrowing['status'] == 'returned') {
            return redirect()->to('/borrowings')->with('message', 'This item has already been returned.');
        }

        // Mark the borrowing record as returned
        $borrowModel->markAsReturned($borrow_id);

        // Update the equipment status to available
        $equipmentModel->updateEquipmentStatus($borrowing['equipment_id'], 'available');

        // Send email notification to the user
        $user = $userModel->getUserDetails($borrowing['user_id']);
        $email = \Config\Services::email();
        $email->setTo($user['email']);
        $email->setSubject('Equipment Return Confirmation');
        $email->setMessage("Dear {$user['name']},\n\nThe equipment you borrowed has been successfully returned.\n\nThank you!");
        $email->send();

        return redirect()->to('/borrowings')->with('message', 'Equipment returned successfully.');
    }
}
