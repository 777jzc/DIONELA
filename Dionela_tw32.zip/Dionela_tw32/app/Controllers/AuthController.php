<?php

namespace App\Controllers;

use App\Models\UserModel;

class Index extends BaseController
{
    // Display login page
    public function login()
    {
        return view('auth/login');
    }

    // Handle login submission
    public function loginSubmit()
    {
        $session = session();
        $model = new UserModel();

        // Form validation
        $validation =  \Config\Services::validation();
        if (!$this->validate([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]'
        ])) {
            return redirect()->back()->withInput()->with('error', 'Invalid input.');
        }

        // Get input values
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Check if user exists
        $user = $model->where('email', $email)->first();

        if ($user) {
            // Verify password
            if (password_verify($password, $user['password'])) {
                $session->set([
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'role' => $user['role'],
                    'isLoggedIn' => true,
                ]);
                return redirect()->to('/dashboard');
            } else {
                return redirect()->back()->withInput()->with('error', 'Invalid password.');
            }
        } else {
            return redirect()->back()->withInput()->with('error', 'Email not found.');
        }
    }

    // Logout
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }

    // Display registration page
    public function register()
    {
        return view('auth/register');
    }

    // Handle registration submission
    public function registerSubmit()
    {
        $model = new UserModel();

        // Form validation
        $validation =  \Config\Services::validation();
        if (!$this->validate([
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]'
        ])) {
            return redirect()->back()->withInput()->with('error', $validation->getErrors());
        }

        // Save new user data
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => 'Associate', // Default role
        ];

        if ($model->save($data)) {
            return redirect()->to('/login')->with('success', 'Registration successful. Please log in.');
        } else {
            return redirect()->back()->with('error', 'An error occurred. Please try again.');
        }
    }

    // Display password reset page
    public function passwordReset()
    {
        return view('auth/password_reset');
    }

    // Handle password reset submission
    public function passwordResetSubmit()
    {
        $model = new UserModel();
        $email = $this->request->getPost('email');

        // Validate email input
        if (!$this->validate([
            'email' => 'required|valid_email'
        ])) {
            return redirect()->back()->withInput()->with('error', 'Please provide a valid email address.');
        }

        // Check if email exists
        $user = $model->where('email', $email)->first();
        if ($user) {
            // Generate a password reset link or email
            // In production, send an actual reset email here
            return redirect()->to('/login')->with('success', 'Password reset link has been sent to your email.');
        } else {
            return redirect()->back()->withInput()->with('error', 'Email not found.');
        }
    }
}
