<?php

namespace App\Controllers;

use App\Models\EquipmentModel;
use App\Models\BorrowingModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class ReportsController extends Controller
{
    public function activeEquipmentReport()
    {
        // Fetch active equipment from the database
        $equipmentModel = new EquipmentModel();
        $activeEquipment = $equipmentModel->where('status', 'active')->findAll();
        
        // Load the report view and pass the data to it
        return view('reports/active_equipment_report', ['equipment' => $activeEquipment]);
    }

    public function unusableEquipmentReport()
    {
        // Fetch unusable equipment from the database
        $equipmentModel = new EquipmentModel();
        $unusableEquipment = $equipmentModel->where('status', 'unusable')->findAll();
        
        // Load the report view and pass the data to it
        return view('reports/unusable_equipment_report', ['equipment' => $unusableEquipment]);
    }

    public function userBorrowingHistory($userId)
    {
        // Fetch borrowing history for a specific user
        $borrowingModel = new BorrowingModel();
        $userHistory = $borrowingModel->where('user_id', $userId)->findAll();
        
        // Fetch the user's name for the report
        $userModel = new UserModel();
        $user = $userModel->find($userId);
        
        // Load the report view and pass the data to it
        return view('reports/user_borrowing_history', ['user' => $user, 'history' => $userHistory]);
    }
}
