<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController // Changed from UserController to Users
{
    // List all users
    public function index()
    {
        $usersModel = model(UserModel::class);

        // Retrieve all users from the database
        $data['users'] = $usersModel->findAll();
        $data['users'] = $usersModel->paginate(2);
        $data['pager'] = $usersModel->pager;
        $data['title'] = "List of Users";

        return view('include/header', $data)
            . view('include/navbar')
            . view('users_view', $data)
            . view('include/footer');
    }

    // Add a new user
    public function add()
    {
        $usersModel = model(UserModel::class);

        if ($this->request->getMethod() === 'post') {
            // Get form input data
            $registerData = [
                'username' => $this->request->getPost('username'),
                'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), // Hash password
                'email' => $this->request->getPost('email'),
                'fullname' => $this->request->getPost('fullname'),
            ];

            // Insert new user into the database
            $usersModel->insert($registerData);

            // Redirect to the users list
            return redirect()->to('/users')->with('success', 'User added successfully.');
        }

        $data['title'] = "Register New User";

        return view('include/header', $data)
            . view('include/navbar')
            . view('registration_view', $data)
            . view('include/footer');
    }

    // View a specific user
    public function view($id = null)
    {
        $usersModel = model(UserModel::class);

        // Retrieve user data by ID
        $data['user'] = $usersModel->find($id);

        if (!$data['user']) {
            return redirect()->to('/users')->with('error', 'User not found.');
        }

        $data['title'] = "View User Account";

        return view('include/header', $data)
            . view('include/navbar')
            . view('user_view', $data)
            . view('include/footer');
    }

    // Edit a specific user
    public function edit($id = null)
    {
        $usersModel = model(UserModel::class);

        $user = $usersModel->find($id);
        if (!$user) {
            return redirect()->to('/users')->with('error', 'User not found.');
        }

        if ($this->request->getMethod() === 'post') {
            // Get form input data
            $updateData = [
                'username' => $this->request->getPost('username'),
                'email' => $this->request->getPost('email'),
                'fullname' => $this->request->getPost('fullname'),
            ];

            // Check if password field is filled
            $password = $this->request->getPost('password');
            if (!empty($password)) {
                $updateData['password'] = password_hash($password, PASSWORD_DEFAULT); // Hash the new password
            }

            // Update user in the database
            $usersModel->update($id, $updateData);

            // Redirect to the users list
            return redirect()->to('/users')->with('success', 'User updated successfully.');
        }

        $data['user'] = $user;
        $data['title'] = "Edit User";

        return view('include/header', $data)
            . view('include/navbar')
            . view('edit_view', $data)
            . view('include/footer');
    }

    // Delete a specific user
    public function delete($id = null)
    {
        $usersModel = model(UserModel::class);

        if (!$usersModel->find($id)) {
            return redirect()->to('/users')->with('error', 'User not found.');
        }

        $usersModel->delete($id);

        return redirect()->to('/users')->with('success', 'User deleted successfully.');
    }
}
