<?php

namespace App\Controllers;

use App\Models\UserModel;

class Index extends BaseController
{
    // Display homepage
    public function index()
    {
        
        $data['title'] = "Welcome to My Blog";

        return view('include/header', $data)
            . view('include/navbar')
            . view('index_view')
            . view('include/footer');
    }

    // About page
    public function about()
    {
        $data['title'] = "About This Page";

        return view('include/header', $data)
            . view('include/navbar')
            . view('about_view')
            . view('include/footer');
    }

    // Login page
    public function login()
{
    if (session()->has('isLogged')) {
        return redirect()->to('/');
    }

    if ($this->request->getMethod() === 'post') {
        $usersModel = new UserModel();
        $logindata = $this->request->getPost(['email', 'password']);

        $user = $usersModel->where('email', $logindata['email'])->first();

        if (!$user || !password_verify($logindata['password'], $user['password'])) {
            session()->setFlashdata('error', 'Invalid email or password.');
            return redirect()->back();
        }

        if (!$user['is_email_verified']) {
            session()->setFlashdata('error', 'Your email is not verified. Please check your email.');
            return redirect()->back();
        }

        session()->set([
            'user_id' => $user['id'],
            'username' => $user['username'],
            'isLoggedIn' => true,
        ]);

        return redirect()->to('/dashboard');
    }

    $data['title'] = "Log In";

    return view('include/header', $data)
        . view('include/navbar')
        . view('login_view')
        . view('include/footer');
}


    // Logout and destroy session
    public function logout()
    {
        session()->destroy(); // Destroy all session data
        return redirect()->to('/login'); // Redirect to login page
    }

    // Register user
    public function register()
{
    if ($this->request->getMethod() === 'post') {
        $formData = $this->request->getPost(['username', 'email', 'password']);

        $usersModel = new UserModel();

        // Check if user already exists
        $existingUser = $usersModel->where('email', $formData['email'])->first();
        if ($existingUser) {
            session()->setFlashdata('error', 'Email already exists!');
            return redirect()->back();
        }

        // Generate email verification token
        $emailToken = bin2hex(random_bytes(32));

        // Save new user with verification token
        $userData = [
            'username' => $formData['username'],
            'email' => $formData['email'],
            'password' => password_hash($formData['password'], PASSWORD_DEFAULT),
            'email_verification_token' => $emailToken,
        ];

        $usersModel->save($userData);

        // Send verification email
        $this->sendVerificationEmail($formData['email'], $emailToken);

        session()->setFlashdata('success', 'Registration successful! Please check your email to verify your account.');
        return redirect()->to('/login');
    }

    $data['title'] = "Register";
    return view('include/header', $data)
        . view('include/navbar')
        . view('register_view')
        . view('include/footer');
}

private function sendVerificationEmail($email, $token)
{
    $emailService = \Config\Services::email();

    $verificationLink = base_url("index/verifyEmail/$token");

    $emailService->setTo($email);
    $emailService->setFrom('noreply@yourdomain.com', 'Your Application');
    $emailService->setSubject('Email Verification');
    $emailService->setMessage("Please click the following link to verify your email: <a href='$verificationLink'>$verificationLink</a>");

    $emailService->send();
}


    public function verifyEmail($token)
{
    $usersModel = new UserModel();

    // Find user by token
    $user = $usersModel->where('email_verification_token', $token)->first();

    if (!$user) {
        session()->setFlashdata('error', 'Invalid or expired token.');
        return redirect()->to('/login');
    }

    // Update user to mark email as verified
    $usersModel->update($user['id'], [
        'is_email_verified' => 1,
        'email_verification_token' => null,
    ]);

    session()->setFlashdata('success', 'Email verified successfully! You can now log in.');
    return redirect()->to('/login');
}


    // Debugging method (to print variables)
    public function dd($data)
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        die();
    }
}
