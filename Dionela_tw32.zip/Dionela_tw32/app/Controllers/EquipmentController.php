<?php

namespace App\Controllers;

use App\Models\Equipment_model;
use CodeIgniter\Controller;

class EquipmentController extends BaseController
{
    // Display the list of equipment
    public function index()
    {
        // Load the model
        $equipmentModel = model('Equipment_model');

        // Retrieve all equipment from the table
        $data['equipment'] = $equipmentModel->findAll();
        $data['title'] = "List of Equipment";

        return view('include/header', $data)
            . view('include/navbar')
            . view('equipment_view', $data)
            . view('include/footer');
    }

    // Add new equipment
    public function add()
    {
        $equipmentModel = model('Equipment_model');

        if ($this->request->getMethod() === 'post') {
            // Validation rules
            $validation =  \Config\Services::validation();
            $validation->setRules([
                'equipment_name' => 'required|min_length[3]|max_length[255]',
                'description' => 'required|min_length[3]',
                'unit' => 'required|min_length[1]',
                'quantity' => 'required|is_natural_no_zero',
                'status' => 'required',
                'supplier' => 'required|min_length[3]',
                'purchase_date' => 'required|valid_date',
                'price' => 'required|decimal'
            ]);

            // Validate the form input
            if (!$validation->withRequest($this->request)->run()) {
                return redirect()->back()->with('error', $validation->getErrors());
            }

            // Retrieve data from the form
            $equipmentData = $this->request->getPost([
                'equipment_name',
                'description',
                'unit',
                'quantity',
                'status',
                'supplier',
                'purchase_date',
                'price',
            ]);

            // Insert the data into the table
            if (!$equipmentModel->insert($equipmentData)) {
                return redirect()->back()->with('error', 'Failed to add equipment.');
            }

            // Redirect to the equipment list page
            return redirect()->to('/equipment')->with('success', 'Equipment added successfully.');
        }

        $data['title'] = "Add New Equipment";

        return view('include/header', $data)
            . view('include/navbar')
            . view('add_equipment_view', $data)
            . view('include/footer');
    }

    // View specific equipment details
    public function view($id = null)
    {
        $equipmentModel = model('Equipment_model');

        // Retrieve equipment data by ID
        $data['equipment'] = $equipmentModel->find($id);

        if (!$data['equipment']) {
            // Redirect or show an error if equipment not found
            return redirect()->to('/equipment')->with('error', 'Equipment not found.');
        }

        $data['title'] = "View Equipment";

        return view('include/header', $data)
            . view('include/navbar')
            . view('equipment_detail_view', $data)
            . view('include/footer');
    }

    // Edit equipment details
    public function edit($id = null)
    {
        $equipmentModel = model('Equipment_model');

        // Retrieve equipment data by ID
        $equipment = $equipmentModel->find($id);

        if (!$equipment) {
            return redirect()->to('/equipment')->with('error', 'Equipment not found.');
        }

        if ($this->request->getMethod() === 'post') {
            // Validation rules
            $validation =  \Config\Services::validation();
            $validation->setRules([
                'equipment_name' => 'required|min_length[3]|max_length[255]',
                'description' => 'required|min_length[3]',
                'unit' => 'required|min_length[1]',
                'quantity' => 'required|is_natural_no_zero',
                'status' => 'required',
                'supplier' => 'required|min_length[3]',
                'purchase_date' => 'required|valid_date',
                'price' => 'required|decimal'
            ]);

            // Validate the form input
            if (!$validation->withRequest($this->request)->run()) {
                return redirect()->back()->with('error', $validation->getErrors());
            }

            // Retrieve data from the form
            $updateData = $this->request->getPost([
                'equipment_name',
                'description',
                'unit',
                'quantity',
                'status',
                'supplier',
                'purchase_date',
                'price',
            ]);

            // Update the equipment in the table
            if (!$equipmentModel->update($id, $updateData)) {
                return redirect()->back()->with('error', 'Failed to update equipment.');
            }

            // Redirect to the equipment list page
            return redirect()->to('/equipment')->with('success', 'Equipment updated successfully.');
        }

        $data['equipment'] = $equipment;
        $data['title'] = "Edit Equipment";

        return view('include/header', $data)
            . view('include/navbar')
            . view('edit_equipment_view', $data)
            . view('include/footer');
    }

    // Delete equipment record
    public function delete($id = null)
    {
        $equipmentModel = model('Equipment_model');

        // Check if the equipment exists
        if (!$equipmentModel->find($id)) {
            return redirect()->to('/equipment')->with('error', 'Equipment not found.');
        }

        // Delete the equipment
        if (!$equipmentModel->delete($id)) {
            return redirect()->to('/equipment')->with('error', 'Failed to delete equipment.');
        }

        return redirect()->to('/equipment')->with('success', 'Equipment deleted successfully.');
    }
}
