<?php

namespace App\Controllers;

use App\Models\BorrowingModel;
use App\Models\EquipmentModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class BorrowingController extends Controller
{
    // Display all borrowing records
    public function index()
    {
        $borrowModel = new BorrowingModel();

        // Fetch all borrowing records, ideally with pagination
        $data['borrowing_records'] = $borrowModel->findAll();

        return view('borrowings_index', $data);
    }

    // View a specific borrowing record
    public function view($borrow_id)
    {
        $borrowModel = new BorrowingModel();
        $equipmentModel = new EquipmentModel();
        $userModel = new UserModel();

        // Fetch the specific borrowing record
        $data['borrowing_record'] = $borrowModel->find($borrow_id);

        if (!$data['borrowing_record']) {
            return redirect()->to('borrowings')->with('error', 'Borrowing record not found');
        }

        // Fetch the equipment and user details
        $data['equipment'] = $equipmentModel->find($data['borrowing_record']['equipment_id']);
        $data['user'] = $userModel->find($data['borrowing_record']['user_id']);

        return view('borrowing_view', $data);
    }

    // Add a new borrowing record
    public function add()
    {
        $equipmentModel = new EquipmentModel();
        $userModel = new UserModel();
        
        // Fetch all available equipment and users for the form
        $data['equipment_list'] = $equipmentModel->where('status', 'available')->findAll();
        $data['user_list'] = $userModel->findAll();

        return view('borrowing_add', $data);
    }

    // Process adding a new borrowing record
    public function create()
    {
        $borrowModel = new BorrowingModel();
        $equipmentModel = new EquipmentModel();
        
        // Get form data
        $equipment_id = $this->request->getPost('equipment_id');
        $user_id = $this->request->getPost('user_id');
        $borrow_date = $this->request->getPost('borrow_date');
        $return_date = $this->request->getPost('return_date');

        // Input validation
        if (!$equipment_id || !$user_id || !$borrow_date || !$return_date) {
            return redirect()->back()->with('error', 'All fields are required');
        }

        // Prepare the data
        $data = [
            'equipment_id' => $equipment_id,
            'user_id' => $user_id,
            'borrow_date' => $borrow_date,
            'return_date' => $return_date,
            'status' => 'borrowed'
        ];

        // Save the new borrowing record
        if (!$borrowModel->save($data)) {
            return redirect()->back()->with('error', 'Failed to borrow equipment');
        }

        // Update equipment status to borrowed
        $equipmentModel->update($equipment_id, ['status' => 'borrowed']);

        // Send an email notification to the user
        $userModel = new UserModel();
        $user = $userModel->find($user_id);
        $email = \Config\Services::email();
        $email->setTo($user['email']);
        $email->setSubject('Equipment Borrowed');
        $email->setMessage("Dear {$user['name']},\n\nYou have successfully borrowed the equipment. Please return it by {$return_date}.");
        $email->send();

        return redirect()->to('borrowings')->with('success', 'Borrowing record created successfully');
    }

    // Return borrowed equipment
    public function return($borrow_id)
    {
        $borrowModel = new BorrowingModel();
        $equipmentModel = new EquipmentModel();

        // Fetch borrowing record
        $record = $borrowModel->find($borrow_id);

        if (!$record) {
            return redirect()->to('borrowings')->with('error', 'Borrowing record not found');
        }

        $equipment_id = $record['equipment_id'];

        // Update the borrowing record status to 'returned'
        $borrowModel->update($borrow_id, ['status' => 'returned']);

        // Update the equipment status back to 'available'
        $equipmentModel->update($equipment_id, ['status' => 'available']);

        // Send an email notification to the user
        $userModel = new UserModel();
        $user = $userModel->find($record['user_id']);
        $email = \Config\Services::email();
        $email->setTo($user['email']);
        $email->setSubject('Equipment Returned');
        $email->setMessage("Dear {$user['name']},\n\nThe equipment you borrowed has been successfully returned.");
        $email->send();

        return redirect()->to('borrowings')->with('success', 'Equipment returned successfully');
    }
}
