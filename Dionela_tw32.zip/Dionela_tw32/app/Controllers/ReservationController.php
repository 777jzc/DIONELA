<?php

namespace App\Controllers;

use App\Models\ReservationModel;
use CodeIgniter\Controller;

class ReservationController extends Controller
{
    public function index()
    {
        $reservationModel = new ReservationModel();
        $associate_id = session()->get('user_id');  // Assuming session has user_id for Associate
        
        $data['reservations'] = $reservationModel->getReservationsByAssociate($associate_id);
        return view('reservation/index', $data);
    }

    public function create()
    {
        $reservationModel = new ReservationModel();
        
        if ($this->request->getMethod() === 'post') {
            $associate_id = session()->get('user_id'); // Assuming session has user_id for Associate
            $equipment_id = $this->request->getPost('equipment_id');
            $reservation_date = $this->request->getPost('reservation_date');
            
            // Validate reservation date (at least a day before)
            $currentDate = new \DateTime();
            $reservationDate = new \DateTime($reservation_date);
            if ($reservationDate < $currentDate->modify('+1 day')) {
                session()->setFlashdata('error', 'You must reserve at least a day in advance.');
                return redirect()->back();
            }

            // Save the reservation
            $reservationModel->createReservation($associate_id, $equipment_id, $reservation_date);
            session()->setFlashdata('success', 'Reservation created successfully.');
            return redirect()->to('reservation');
        }

        return view('reservation/create');
    }

    public function cancel($reservation_id)
    {
        $reservationModel = new ReservationModel();
        
        $reservationModel->cancelReservation($reservation_id);
        session()->setFlashdata('success', 'Reservation cancelled.');
        return redirect()->to('reservation');
    }

    public function reschedule($reservation_id)
    {
        $reservationModel = new ReservationModel();
        
        if ($this->request->getMethod() === 'post') {
            $new_date = $this->request->getPost('new_date');
            $reservationModel->rescheduleReservation($reservation_id, $new_date);
            session()->setFlashdata('success', 'Reservation rescheduled successfully.');
            return redirect()->to('reservation');
        }
        
        return view('reservation/reschedule', ['reservation_id' => $reservation_id]);
    }
}
