<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateReservationsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'associate_id' => [
                'type'           => 'INT',
                'unsigned'       => true,
            ],
            'equipment_id' => [
                'type'           => 'INT',
                'unsigned'       => true,
            ],
            'reservation_date' => [
                'type'           => 'DATE',
            ],
            'status' => [
                'type'           => 'ENUM',
                'constraint'     => ['reserved', 'cancelled', 'completed'],
                'default'        => 'reserved',
            ],
            'created_at' => [
                'type'           => 'DATETIME',
                'default'        => 'CURRENT_TIMESTAMP',
            ],
            'updated_at' => [
                'type'           => 'DATETIME',
                'default'        => 'CURRENT_TIMESTAMP',
                'on_update'      => 'CURRENT_TIMESTAMP',
            ]
        ]);
        
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('associate_id', 'users', 'id', 'CASCADE', 'CASCADE');  // Assuming 'users' table has the Associates
        $this->forge->addForeignKey('equipment_id', 'equipment', 'id', 'CASCADE', 'CASCADE');  // Assuming 'equipment' table exists
        $this->forge->createTable('reservations');
    }

    public function down()
    {
        $this->forge->dropTable('reservations');
    }
}
