<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateBorrowingRecordsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'borrow_id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type' => 'INT',
            ],
            'equipment_id' => [
                'type' => 'INT',
            ],
            'borrow_date' => [
                'type' => 'DATE',
            ],
            'return_date' => [
                'type' => 'DATE',
            ],
            'status' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
        ]);

        $this->forge->addKey('borrow_id', true);
        $this->forge->createTable('borrowing_records');
    }

    public function down()
    {
        $this->forge->dropTable('borrowing_records');
    }
}
